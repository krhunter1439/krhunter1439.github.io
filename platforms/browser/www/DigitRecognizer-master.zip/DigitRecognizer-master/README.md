# http://ramok.tech/machine-learning/
Java Digit Recognition Application 

Hand Writing Digit Recognition using Simple Neural Networks with Spark Mlib
and
Deep Convolution Neural Network with DeepLearning4j

Acuracy with simple model 97% 
and 
with convolutional neural network 99.2%

For more please visit below posts:

http://ramok.tech/2017/11/29/digit-recognizer-with-neural-networks/

http://ramok.tech/2017/12/13/java-digit-recognizer-with-convolutional-neural-networks/

<p align="center">
  <img src="https://i0.wp.com/ramok.tech/wp-content/uploads/2017/12/2017-12-14_01h00_37.jpg?resize=1024%2C537e" width="600"/>
</p>


License to EPL https://www.eclipse.org/legal/epl-v10.html